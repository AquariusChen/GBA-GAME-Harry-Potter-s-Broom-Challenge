/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 hp hp.png 
 * Time-stamp: Thursday 04/02/2020, 01:19:42
 * 
 * Image Information
 * -----------------
 * hp.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef HP_H
#define HP_H

extern const unsigned short hp[38400];
#define HP_SIZE 76800
#define HP_LENGTH 38400
#define HP_WIDTH 240
#define HP_HEIGHT 160

#endif

