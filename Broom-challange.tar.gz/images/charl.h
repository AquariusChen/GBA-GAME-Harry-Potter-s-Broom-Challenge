/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=40x40 charl characterl.BMP 
 * Time-stamp: Thursday 04/02/2020, 12:30:07
 * 
 * Image Information
 * -----------------
 * characterl.BMP 40@40
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CHARL_H
#define CHARL_H

extern const unsigned short characterl[1600];
#define CHARACTERL_SIZE 3200
#define CHARACTERL_LENGTH 1600
#define CHARACTERL_WIDTH 40
#define CHARACTERL_HEIGHT 40

#endif

