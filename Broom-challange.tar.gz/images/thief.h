/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=8x8 thief thief.BMP 
 * Time-stamp: Thursday 04/02/2020, 13:05:12
 * 
 * Image Information
 * -----------------
 * thief.BMP 8@8
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef THIEF_H
#define THIEF_H

extern const unsigned short thief[64];
#define THIEF_SIZE 128
#define THIEF_LENGTH 64
#define THIEF_WIDTH 8
#define THIEF_HEIGHT 8

#endif

