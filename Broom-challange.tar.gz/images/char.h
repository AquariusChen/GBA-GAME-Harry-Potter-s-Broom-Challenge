/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=25x25 char character.BMP 
 * Time-stamp: Thursday 04/02/2020, 12:29:40
 * 
 * Image Information
 * -----------------
 * character.BMP 25@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CHAR_H
#define CHAR_H

extern const unsigned short character[625];
#define CHARACTER_SIZE 1250
#define CHARACTER_LENGTH 625
#define CHARACTER_WIDTH 25
#define CHARACTER_HEIGHT 25

#endif

