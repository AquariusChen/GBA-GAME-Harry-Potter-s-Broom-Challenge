/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=25x25 charb character-b.BMP 
 * Time-stamp: Thursday 04/02/2020, 12:50:38
 * 
 * Image Information
 * -----------------
 * character-b.BMP 25@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CHARB_H
#define CHARB_H

extern const unsigned short characterb[625];
#define CHARACTERB_SIZE 1250
#define CHARACTERB_LENGTH 625
#define CHARACTERB_WIDTH 25
#define CHARACTERB_HEIGHT 25

#endif

