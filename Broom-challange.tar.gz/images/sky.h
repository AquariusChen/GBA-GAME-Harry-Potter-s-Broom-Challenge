/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 sky sky.BMP 
 * Time-stamp: Thursday 04/02/2020, 13:04:36
 * 
 * Image Information
 * -----------------
 * sky.BMP 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SKY_H
#define SKY_H

extern const unsigned short sky[38400];
#define SKY_SIZE 76800
#define SKY_LENGTH 38400
#define SKY_WIDTH 240
#define SKY_HEIGHT 160

#endif

