#ifndef GAME_H
#define GAME_H

#include "gba.h"

                    /* TODO: */

            // Create any necessary structs //


/*
* For example, for a Snake game, one could be:
*
* typedef struct snake {
*   int heading;
*   int length;
*   int row;
*   int col;
* } Snake;
*
*
* 
*
*
* Example of a struct to hold state machine data:
* 
* typedef struct state {
*   int currentState;
*   int nextState;
* } State
*
*/
typedef struct harry {
    int row;
    int col;
    int width;
    const u16* image;
}Harry;

typedef struct goldenThief {
    int row;
    int col;
    int width;
    const u16* image;
}Thief;

#endif
