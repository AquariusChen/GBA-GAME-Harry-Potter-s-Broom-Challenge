#include "gba.h"

volatile unsigned short *videoBuffer = (volatile unsigned short *)0x6000000;
u32 vBlankCounter = 0;

void waitForVBlank(void) {
  // TODO: IMPLEMENT

  // (1)
  // Write a while loop that loops until we're NOT in vBlank anymore:
  // (This prevents counting one VBlank more than once if your app is too fast)
  while (SCANLINECOUNTER > 160);

  // (2)
  // Write a while loop that keeps going until we're in vBlank:
  while (SCANLINECOUNTER < 160);

  // (3)
  // Finally, increment the vBlank counter:
  vBlankCounter++;
}

static int __qran_seed = 42;
static int qran(void) {
  __qran_seed = 1664525 * __qran_seed + 1013904223;
  return (__qran_seed >> 16) & 0x7FFF;
}

int randint(int min, int max) { return (qran() * (max - min) >> 15) + min; }

void delay(int n) {
    volatile int x = 0;
    for (int i = 0; i < n * 8000; i++) {
        x++;
    }
}

void setPixel(int row, int col, u16 color) {
  videoBuffer[OFFSET(row, col, WIDTH)] = color;
  UNUSED(row);
  UNUSED(col);
  UNUSED(color);
}

void drawRectDMA(int row, int col, int width, int height, volatile u16 color) {
  for (int r = 0; r < height; r++) {
      DMA[DMA_CHANNEL_3].src = &color;
      DMA[DMA_CHANNEL_3].dst = &videoBuffer[OFFSET(row + r, col, WIDTH)];
      DMA[DMA_CHANNEL_3].cnt = width | DMA_ON | DMA_SOURCE_FIXED;
  }
  UNUSED(row);
  UNUSED(col);
  UNUSED(width);
  UNUSED(height);
  UNUSED(color);
}

void drawFullScreenImageDMA(const u16 *image) {
    DMA[DMA_CHANNEL_3].cnt = 0;
    DMA[DMA_CHANNEL_3].src = image;
    DMA[DMA_CHANNEL_3].dst = videoBuffer;
    DMA[DMA_CHANNEL_3].cnt = (WIDTH * HEIGHT) | DMA_ON;
    UNUSED(image);
}

void drawImageDMA(int row, int col, int width, int height, const u16 *image) {
    for (int r = 0; r < height; r++) {
        DMA[DMA_CHANNEL_3].src = &image[OFFSET(r, width, width)];
        DMA[DMA_CHANNEL_3].dst = &videoBuffer[OFFSET(row + r, col, WIDTH)];
        DMA[DMA_CHANNEL_3].cnt = width | DMA_SOURCE_INCREMENT | DMA_DESTINATION_INCREMENT | DMA_ON;
    }
    UNUSED(row);
    UNUSED(col);
    UNUSED(width);
    UNUSED(height);
    UNUSED(image);
}

void drawHImageDMA(int row, int col, int width, int height, const u16 *image) {
    for (int r = 0; r < height; r++) {
        DMA[DMA_CHANNEL_3].src = &image[OFFSET(row + r, col, WIDTH)];
        DMA[DMA_CHANNEL_3].dst = &videoBuffer[OFFSET(row + r, col, WIDTH)];
        DMA[DMA_CHANNEL_3].cnt = width | DMA_SOURCE_INCREMENT | DMA_DESTINATION_INCREMENT | DMA_ON;
    }
}

void drawImageLine(int row, int col, int width, int height, const u16 *image, u16 color) {
    for (int r = 0; r < height; r++) {
        for (int c = 0; c < width; c++){
            if (image[OFFSET(r, c, width)] != color) {
                setPixel(row + r, col + c, image[OFFSET(r, c, width)]);
            }
        }
    }
}

int detectGrayA(int x, int y, const u16 *image, const u16 *player, u16 color) {
    for (int r = 0; r < 20; r++) {
        for (int c = 0; c < 20; c++){
            if (player[OFFSET(r, c, 25)] != 0x7323 && image[OFFSET(r + x, c + y, WIDTH)] == color) {
                return 0;
            }
        }
    }
    return 1;
}

int catch(int x, int y, const u16 *image, const u16 *player, u16 color) {
    for (int r = 0; r < 32; r++) {
        for (int c = 0; c < 32; c++){
            if (player[OFFSET(r, c, 30)] != 0x7323 && (videoBuffer[OFFSET(r + x, c + y, WIDTH)] == color || videoBuffer[OFFSET(r + x, c + y, WIDTH)] == 0x67be)) {
                return 0;
            }
        }
    }
    UNUSED(image);
    return 1;
}

void fillScreenDMA(volatile u16 color) {
    DMA[DMA_CHANNEL_3].cnt = 0;
    DMA[DMA_CHANNEL_3].src = &color;
    DMA[DMA_CHANNEL_3].dst = videoBuffer;
    DMA[DMA_CHANNEL_3].cnt = (WIDTH * HEIGHT) | DMA_ON | DMA_SOURCE_FIXED;
    UNUSED(color);
}

void drawChar(int row, int col, char ch, u16 color) {
  for (int i = 0; i < 6; i++) {
    for (int j = 0; j < 8; j++) {
      if (fontdata_6x8[OFFSET(j, i, 6) + ch * 48]) {
        setPixel(row + j, col + i, color);
      }
    }
  }
}

void drawString(int row, int col, char *str, u16 color) {
  while (*str) {
    drawChar(row, col, *str++, color);
    col += 6;
  }
}

void drawCenteredString(int row, int col, int width, int height, char *str,
                        u16 color) {
  u32 len = 0;
  char *strCpy = str;
  while (*strCpy) {
    len++;
    strCpy++;
  }

  u32 strWidth = 6 * len;
  u32 strHeight = 8;

  int new_row = row + ((height - strHeight) >> 1);
  int new_col = col + ((width - strWidth) >> 1);
  drawString(new_row, new_col, str, color);
}
